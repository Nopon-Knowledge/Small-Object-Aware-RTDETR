#!/usr/bin/env bash
set -euo pipefail

JOB_NAME="${JOB_NAME:-rtdetr_wheat_tsecaf}"
PROJECT_DIR="${PROJECT_DIR:-/storage/home/402005/python_project/RT-DETR-main/rtdetrv2_pytorch}"
PYTHON_BIN="${PYTHON_BIN:-/storage/home/402005/venvs/rtdetr_env/bin/python}"
TRAIN_SCRIPT="${TRAIN_SCRIPT:-tools/train_gwhd_a40.py}"
LOG_DIR="${LOG_DIR:-$HOME/logs}"

mkdir -p "$LOG_DIR"

jsub \
  -q gpu \
  -gpgpu 1 \
  -J "$JOB_NAME" \
  -o "$LOG_DIR/${JOB_NAME}.%J.out" \
  -e "$LOG_DIR/${JOB_NAME}.%J.err" \
  -cwd "$PROJECT_DIR" \
  "$PYTHON_BIN" "$TRAIN_SCRIPT" --preset wheat_tsecaf
